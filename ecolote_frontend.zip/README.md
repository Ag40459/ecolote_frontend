```md
📘 Documentação complementar:
- [Manual da Função `solarCalculator`](./docs/solarCalculator.md)
```