import { useState, useEffect } from 'react';
import styles from './SimulationModal.module.css';
import { solarCalculator, formatCurrency } from '../../utils/calc';
import { formatPhone, formatCep } from '../../utils/formatters';
import { fetchCepData } from '../../utils/cepService';
import apiClient from '../../services/apiClient';
import VerificationCodeModal from '../ContactModal/VerificationCodeModal';

// Componente de animação para o canto superior esquerdo
const EnergyPulseAnimation = () => (
  <div className={styles.energyPulseContainer}>
    <div className={styles.energyPulseOuter}></div>
    <div className={styles.energyPulseMiddle}></div>
    <div className={styles.energyPulseInner}></div>
  </div>
);

// Componente para o modal de pretensão de pagamento
const PaymentIntentionModal = ({ isOpen, onClose, onSelect }) => {
  if (!isOpen) return null;

  const options = [
    { value: "avista", label: "À vista", order: 1 },
    { value: "financiado", label: "Financiado", order: 2 },
    { value: "cartao", label: "Cartão", order: 3 }
  ];

  return (
    <div className={styles.intentionModalOverlay}>
      <div className={styles.intentionModalContainer}>
        <button 
          className={styles.modalCloseButton} 
          onClick={onClose}
          aria-label="Fechar modal"
        >×</button>
        <h3 className={styles.intentionModalTitle}>Pretensão de Pagamento</h3>
        <p className={styles.intentionModalSubtitle}>
          Como você pretende realizar o pagamento?
        </p>
        <div className={styles.intentionOptions}>
          {options.map(option => (
            <button 
              key={option.value}
              className={styles.intentionOption}
              onClick={() => onSelect(option.value)}
              style={{"--animation-order": option.order}}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

const SimulationModal = ({ initialValue, onClose }) => {
  // Estados do formulário
  const [step, setStep] = useState('form'); // 'form' ou 'results'
  const [billValue, setBillValue] = useState(initialValue || 200);
  const [formattedBillValue, setFormattedBillValue] = useState('');
  const [profileType, setProfileType] = useState('pessoal');
  const [cep, setCep] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState({
    logradouro: '',
    bairro: '',
    cidade: '',
    estado: ''
  });
  const [loadingCep, setLoadingCep] = useState(false);
  const [cepError, setCepError] = useState('');
  const [paymentIntention, setPaymentIntention] = useState('');
  
  // Estados para modais
  const [isPaymentIntentionModalOpen, setIsPaymentIntentionModalOpen] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState('');
  
  // Estado para armazenar resultados da simulação
  const [results, setResults] = useState(null);

  // Formatar o valor inicial
  useEffect(() => {
    setFormattedBillValue(formatCurrency(billValue.toString(), 'input'));
  }, [billValue]);

  // Função para lidar com a mudança no valor da conta
 const handleBillValueChange = (e) => {
  const raw = e.target.value.replace(/\D/g, '');
  const numeric = raw ? parseInt(raw, 10) : 0;

  setBillValue(numeric);
  setFormattedBillValue(formatCurrency(numeric, 'input'));
};

  // Função para buscar dados do CEP
  const handleCepChange = async (e) => {
    const formattedCep = formatCep(e.target.value);
    setCep(formattedCep);
    
    // Buscar dados do CEP quando tiver 8 dígitos
    if (formattedCep.replace(/\D/g, '').length === 8) {
      setLoadingCep(true);
      setCepError('');
      
      try {
        const data = await fetchCepData(formattedCep);
        setAddress({
          logradouro: data.logradouro || '',
          bairro: data.bairro || '',
          cidade: data.localidade || '',
          estado: data.uf || ''
        });
      } catch (error) {
        setCepError(error.message || 'Erro ao buscar CEP');
      } finally {
        setLoadingCep(false);
      }
    }
  };

  // Função para lidar com o envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Calcula resultados com base no valor da conta
    const specifications = solarCalculator({ monthlyBill: billValue });
    setResults(specifications);
    
    // Muda para a etapa de resultados
    setStep('results');
  };

  // Função para iniciar o pré-cadastro
  const handlePreRegister = () => {
    setIsPaymentIntentionModalOpen(true);
  };

  // Função para processar a seleção de pretensão de pagamento
  const handlePaymentIntentionSelect = async (intention) => {
    setPaymentIntention(intention);
    setIsPaymentIntentionModalOpen(false);
    
    // Iniciar processo de verificação de email
    setIsSubmitting(true);
    setSubmitError('');
    
    try {
      // Enviar solicitação de código de verificação
      await apiClient.post('/verificacao/enviar-codigo', { email });
      
      
      // Abrir modal de verificação
      setIsVerificationModalOpen(true);
    } catch (error) {
      console.error("Erro ao iniciar verificação:", error);
      setSubmitError(error.response?.data?.message || "Não foi possível iniciar a verificação. Tente novamente mais tarde.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Função para verificar o código
  const handleVerifyCode = async (code) => {
    try {
      // Verifica o código
      await apiClient.post('/verificacao/validar-codigo', {
        email: email,
        codigo: code
      });
      
      // Se o código for válido, prepara os dados para envio
      let endpoint = '';
      let payload = {};
      
      // Prepara os dados de acordo com o tipo de perfil
      if (profileType === 'pessoal') {
        endpoint = '/pessoas-fisicas';
        payload = {
          nome_completo: name,
          telefone: phone,
          email: email,
          modelo_imovel: 'Casa', // Valor padrão, pode ser ajustado
          media_conta_energia: billValue.toString(),
          cep: cep,
          rua: address.logradouro,
          numero: '', // Precisa ser preenchido pelo usuário em etapa posterior
          bairro: address.bairro,
          cidade: address.cidade,
          estado: address.estado,
          pretensao_pagamento: paymentIntention
        };
      } else if (profileType === 'empresa') {
        endpoint = '/pessoas-juridicas';
        payload = {
          razao_social: name,
          telefone_comercial: phone,
          email_comercial: email,
          tipo_imovel_comercial: 'Comercial', // Valor padrão
          media_conta_energia_pj: billValue,
          cep_pj: cep,
          rua_pj: address.logradouro,
          bairro_pj: address.bairro,
          cidade_pj: address.cidade,
          estado_pj: address.estado,
          pretensao_pagamento_pj: paymentIntention
        };
      } else if (profileType === 'investidor') {
        endpoint = '/investidores';
        payload = {
          nome: name,
          email: email,
          telefone: phone,
          cidade: address.cidade,
          estado: address.estado,
          valor_investimento: billValue.toString(),
          tipo_investidor: 'Pessoa Física' // Valor padrão
        };
      }
      
      // Envia os dados para o backend
      const response = await apiClient.post(endpoint, payload);
      
      // Fecha o modal de verificação
      setIsVerificationModalOpen(false);
      
      // Fecha o modal principal
      onClose();
      
      // Exibe mensagem de sucesso (pode ser implementado de outra forma)
      alert('Pré-cadastro realizado com sucesso!');
      
    } catch (error) {
      console.error("Erro na verificação:", error);
      throw new Error(
        error.response?.data?.message || "Código inválido. Por favor, tente novamente."
      );
    }
  };

  // Função para reenviar o código
  const handleResendCode = async () => {
    try {
      await apiClient.post('/verificacao/enviar-codigo', { email });
      console.log(email);
    } catch (error) {
      console.error("Erro ao reenviar código:", error);
    }
  };

  // Renderiza o formulário de simulação
  const renderForm = () => (
    <>
      <div className={styles.modalHeader}>
        <button 
        id='simulation'
          className={styles.modalCloseButton} 
          onClick={onClose}
          aria-label="Fechar modal"
        >×</button>
        <div className={styles.modalIllustration}>
          <EnergyPulseAnimation />
        </div>
      </div>
      
      <div  className={styles.modalContent}>
        <h2 className={`${styles.modalTitle} sectionTitle`}>Calcule Sua Economia Solar</h2>
        <p className={styles.modalSubtitle}>
          Descubra em segundos quanto você economizará com seu Ecolote e como ele se pagará ao longo do tempo.
        </p>
        
        <form onSubmit={handleSubmit}>
          <div className={styles.formGroup} style={{"--animation-order": 1}}>
            <label className={styles.formLabel}>Valor médio da sua conta de luz:</label>
            <div className={styles.currencyInputWrapper}>
              <input
                type="text"
                className={styles.formInput}
                value={formattedBillValue}
                onChange={handleBillValueChange}
                required
                aria-label="Valor médio mensal da conta de energia"
              />
            </div>
          </div>
          
          <div className={styles.formGroup} style={{"--animation-order": 2}}>
            <label className={styles.formLabel}>Tipo de uso:</label>
            <div className={styles.radioGroup}>
              <div className={styles.radioOption}>
                <input
                  type="radio"
                  id="pessoal"
                  name="profileType"
                  value="pessoal"
                  checked={profileType === 'pessoal'}
                  onChange={() => setProfileType('pessoal')}
                  className={styles.radioInput}
                />
                <label htmlFor="pessoal" className={styles.radioLabel}>Residencial</label>
              </div>
              
              <div className={styles.radioOption}>
                <input
                  type="radio"
                  id="empresa"
                  name="profileType"
                  value="empresa"
                  checked={profileType === 'empresa'}
                  onChange={() => setProfileType('empresa')}
                  className={styles.radioInput}
                />
                <label htmlFor="empresa" className={styles.radioLabel}>Empresarial</label>
              </div>
              
              <div className={styles.radioOption}>
                <input
                  type="radio"
                  id="investidor"
                  name="profileType"
                  value="investidor"
                  checked={profileType === 'investidor'}
                  onChange={() => setProfileType('investidor')}
                  className={styles.radioInput}
                />
                <label htmlFor="investidor" className={styles.radioLabel}>Investimento</label>
              </div>
            </div>
          </div>
          
          <div className={styles.formGroup} style={{"--animation-order": 3}}>
            <label className={styles.formLabel}>CEP</label>
            <input
              type="text"
              className={styles.formInput}
              value={cep}
              onChange={handleCepChange}
              placeholder="00000-000"
              required
              aria-label="CEP para instalação"
            />
            {loadingCep && <p className={styles.loadingMessage}>Buscando CEP...</p>}
            {cepError && <p className={styles.errorMessage}>{cepError}</p>}
          </div>
          
          <div className={styles.formGroup} style={{"--animation-order": 4}}>
            <label className={styles.formLabel}>Nome e sobrenome</label>
            <input
              type="text"
              className={styles.formInput}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              aria-label="Nome completo"
            />
          </div>
          
          <div className={styles.formGroup} style={{"--animation-order": 5}}>
            <label className={styles.formLabel}>Email</label>
            <input
              type="email"
              className={styles.formInput}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              aria-label="Endereço de email"
            />
          </div>
          
          <div className={styles.formGroup} style={{"--animation-order": 6}}>
            <label className={styles.formLabel}>Telefone ou WhatsApp</label>
            <input
              type="tel"
              className={styles.formInput}
              value={phone}
              onChange={(e) => setPhone(formatPhone(e.target.value))}
              placeholder="(00) 00000-0000"
              required
              aria-label="Número de telefone ou WhatsApp"
            />
          </div>
          
          <button type="submit" className={`${styles.submitButton} cta-button`}>
            Calcular Minha Economia
          </button>
        </form>
      </div>
    </>
  );

  // Renderiza os resultados da simulação
  const renderResults = () => (
    <>
      <div className={styles.modalHeader}>
        <button 
          className={styles.modalCloseButton} 
          onClick={onClose}
          aria-label="Fechar modal"
        >×</button>
        <div className={styles.modalIllustration}>
          <EnergyPulseAnimation />
        </div>
      </div>
      
      <div className={styles.modalContent}>
        <h2 className={`${styles.modalTitle} sectionTitle`}>Sua Economia Personalizada</h2>
        <p className={styles.modalSubtitle}>
          Veja como o Ecolote transforma sua conta de luz em investimento e quanto você pode economizar.
        </p>
        
        <div className={styles.resultsContainer}>
          <div className={styles.comparison}>
            <div className={`${styles.comparisonItem} ${styles.comparisonItemCurrent}`}>
              <div className={styles.comparisonLabel}>Valor Atual da Conta</div>
              <div className={styles.comparisonValue}>{formatCurrency(results.monthlyBill, 'display')}</div>
            </div>
            
            <div className={`${styles.comparisonItem} ${styles.comparisonItemInstallment}`}>
              <div className={styles.comparisonLabel}>Valor da Sua Parcela</div>
              <div className={styles.comparisonValue}>{formatCurrency(results.monthlyInstallment, 'display')}</div>
            </div>
          </div>
          
          <div className={styles.totalValue}>
            <span className={styles.oldValue}>
              Valor do Total do Projeto: {formatCurrency(results.estimatedProjectCost + results.discount, 'display')}
            </span>
            <br />
            <span className={styles.newValue}>
              Ecolote com Desconto: {formatCurrency(results.estimatedProjectCost, 'display')}
            </span>
          </div>
          
          <div className={styles.specificationCard2}>
            <div className={styles.specificationIcon}>💰</div>
            <div className={styles.specificationLabel}>Desconto Pré-Cadastro</div>
            <div className={styles.specificationValue}>{formatCurrency(results.discount, 'display')}</div>
          </div>

          <div className={styles.specificationsGrid}>
            <div className={styles.specificationCard} style={{"--animation-order": 1}}>
              <div className={styles.specificationIcon}>📅</div>
              <div className={styles.specificationLabel}>Para Conta Informada</div>
              <div className={styles.specificationValue}>{results.consumptionKwh} {'kWh'}</div>
            </div>
            
            <div className={styles.specificationCard} style={{"--animation-order": 2}}>
              <div className={styles.specificationIcon}>⚡</div>
              <div className={styles.specificationLabel}>Geração Média Equipamento</div>
              <div className={styles.specificationValue}>{results.realGenerationKwh} {'kWh'}</div>
            </div>
            
            <div className={styles.specificationCard} style={{"--animation-order": 3}}>
              <div className={styles.specificationIcon}>🔋</div>
              <div className={styles.specificationLabel}>Potência do Sistema</div>
              <div className={styles.specificationValue}>{results.finalPowerKwp} {'kWp'}</div>
            </div>
            
            <div className={styles.specificationCard} style={{"--animation-order": 4}}>
              <div className={styles.specificationIcon}>🌞</div>
              <div className={styles.specificationLabel}>Quantidade de Painéis</div>
              <div className={styles.specificationValue}>{results.modules} {'un'}</div>
            </div>
            
            <div className={styles.specificationCard} style={{"--animation-order": 5}}>
              <div className={styles.specificationIcon}>💹</div>
              <div className={styles.specificationLabel}>Economia em 25 anos</div>
              <div className={styles.specificationValue}>{formatCurrency(results.lifetimeSavings, 'display')}</div>
            </div>
            
            <div className={styles.specificationCard} style={{"--animation-order": 6}}>
              <div className={styles.specificationIcon}>⏱️</div>
              <div className={styles.specificationLabel}>Tempo de Retorno</div>
              <div className={styles.specificationValue}>{results.paybackPeriod} {'anos'}</div>
            </div>
          </div>
          
          <div className={styles.installmentNote}>
            * As parcelas são simuladas com base em financiamento em 60 meses (5 anos). Consulte condições específicas para seu perfil.
          </div>
          
          <button 
            className={styles.preCadastroButton}
            onClick={handlePreRegister}
          >
            Quero Garantir Meu Desconto
          </button>
        </div>
      </div>
    </>
  );

  // Renderiza o modal de verificação de código
  const renderVerificationModal = () => (
    <VerificationCodeModal
      isOpen={isVerificationModalOpen}
      onClose={() => setIsVerificationModalOpen(false)}
      onVerify={handleVerifyCode}
      onResend={handleResendCode}
      email={email}
    />
  );

  // Renderiza o modal de pretensão de pagamento
  const renderPaymentIntentionModal = () => (
    <PaymentIntentionModal
      isOpen={isPaymentIntentionModalOpen}
      onClose={() => setIsPaymentIntentionModalOpen(false)}
      onSelect={handlePaymentIntentionSelect}
    />
  );

  return (
    <div className={styles.modalOverlay}>
      <div className={styles.modalContainer}>
        {step === 'form' ? renderForm() : renderResults()}
        {renderVerificationModal()}
        {renderPaymentIntentionModal()}
      </div>
    </div>
  );
};

export default SimulationModal;
