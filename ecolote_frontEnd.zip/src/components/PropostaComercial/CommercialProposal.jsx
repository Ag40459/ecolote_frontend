import React from 'react';
import './CommercialProposal.module.css';

const PropostaComercial = ({
  numeroPropostaProp = "2504081551029",
  dataPropostaProp = "08/04/2025",
  validadeProp = "7 dias",
  agenorNome = "Agenor Torres",
  valorContaLuz = "400,00",
  economiaAnos = "105.609,12",
  valorSistema = "14.390,88",
  parcelas = [
    { parcelas: "84x de", valor: "R$ 445,23", destaque: true },
    { parcelas: "36x de", valor: "R$ 701,76", destaque: false },
    { parcelas: "48x de", valor: "R$ 584,75", destaque: false },
    { parcelas: "60x de", valor: "R$ 517,17", destaque: false },
    { parcelas: "72x de", valor: "R$ 474,21", destaque: false },
    { parcelas: "84x de", valor: "R$ 445,23", destaque: false }
  ]
}) => {
  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Olá! Gostaria de personalizar minha proposta de energia solar.");
    window.open(`https://wa.me/5581985967343?text=${message}`, '_blank');
  };

  return (
    <div className="proposta-comercial">
      <div className="proposta-header">
        <div className="header-content">
          <div className="header-text">
            <h1>Soluções energéticas de confiança,</h1>
            <h2>com uma parceria para vida!</h2>
          </div>
          <div className="header-logo">
            <img src="/logo.png" alt="Eolote" className="logo-img" />
          </div>
        </div>
      </div>

      <div className="proposta-body">
        <div className="proposta-info">
          <div className="info-left">
            <h2>PROPOSTA COMERCIAL</h2>
            <p className="agenor-name">{agenorNome}</p>
          </div>
          <div className="info-right">
            <p><strong>Número da Proposta:</strong> {numeroPropostaProp}</p>
            <p><strong>Data da proposta:</strong> {dataPropostaProp}</p>
            <p><strong>Válida por {validadeProp}.</strong></p>
          </div>
        </div>

        <div className="resumo-section">
          <h3>RESUMO FINANCEIRO DA PROPOSTA</h3>
          <div className="resumo-cards">
            <div className="resumo-card">
              <div className="card-icon conta-luz">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2L2 7v10c0 5.55 3.84 9.739 9 11 5.16-1.261 9-5.45 9-11V7l-10-5z"/>
                </svg>
              </div>
              <div className="card-content">
                <p>Valor indicado da conta de luz</p>
                <h4>R$ {valorContaLuz}</h4>
              </div>
            </div>
            <div className="resumo-card">
              <div className="card-icon economia">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <div className="card-content">
                <p>Sua economia em 25 anos</p>
                <h4>R$ {economiaAnos}</h4>
              </div>
            </div>
          </div>
          
          <div className="valor-sistema-card">
            <h3>Valor do sistema instalado</h3>
            <div className="valor-principal">R$ {valorSistema}</div>
            <p>à vista, com Pix, Boleto Bancário,</p>
            <p>ou em até 12 vezes de R$ 1.326,00 no Cartão.</p>
          </div>
        </div>

        <div className="financiamento-section">
          <h3>FINANCIAMENTO DESCARBONIZE</h3>
          <p className="financiamento-desc">Parcelas fixas, com o pagamento da 1ª parcela em 4 meses.</p>
          
          <div className="parcelas-grid">
            {parcelas.map((parcela, index) => (
              <div key={index} className={`parcela-card ${parcela.destaque ? 'destaque' : ''}`}>
                <div className="parcela-info">
                  <span className="parcela-qtd">{parcela.parcelas}</span>
                  <span className="parcela-valor">{parcela.valor}</span>
                </div>
                {parcela.destaque && (
                  <div className="melhor-opcao">Melhor opção</div>
                )}
              </div>
            ))}
          </div>
          
          <p className="financiamento-obs">Sujeito a aprovação de crédito. Outras opções de pagamento sob consulta.</p>
        </div>

        <div className="whatsapp-section">
          <button className="whatsapp-button" onClick={handleWhatsAppClick}>
            <svg viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.516"/>
            </svg>
            <div>
              <span className="whatsapp-title">Esta proposta pode ser personalizada!</span>
              <span className="whatsapp-subtitle">Solicite a um de nossos especialistas</span>
            </div>
          </button>
        </div>

        <div className="beneficios-section">
          <h3>PARA SEU BOLSO</h3>
          <div className="beneficios-content">
            <div className="beneficios-lista">
              <div className="beneficio-item">
                <div className="beneficio-icon">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
                <span>Instalação e Entrega sem custo adicional</span>
              </div>
              <div className="beneficio-item">
                <div className="beneficio-icon">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
                <span>Redução de até 100% no consumo de energia</span>
              </div>
              <div className="beneficio-item">
                <div className="beneficio-icon">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
                <span>Valorização do imóvel</span>
              </div>
              <div className="beneficio-item">
                <div className="beneficio-icon">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
                <span>Até 20% de desconto no IPTU, em regiões que adotam o IPTU verde</span>
              </div>
              <div className="beneficio-item">
                <div className="beneficio-icon">
                  <svg viewBox="0 0 24 24" fill="currentColor">
                    <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/>
                  </svg>
                </div>
                <span>Crédito na conta de luz</span>
              </div>
            </div>
            <div className="beneficios-imagem">
              <div className="casa-solar"></div>
            </div>
          </div>
        </div>

        <div className="footer-section">
          <div className="footer-content">
            <div className="footer-logo">
              <span className="desc-text">DESC</span>
              <span className="arbonize-text">ARBONIZE</span>
              <span className="solucoes-text">SOLUÇÕES</span>
            </div>
            <div className="footer-contact">
              <span className="website">www.colote.com.br</span>
              <div className="phone-contact">
                <svg viewBox="0 0 24 24" fill="currentColor">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893A11.821 11.821 0 0020.465 3.516"/>
                </svg>
                <span>(81) 98596-7343</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropostaComercial;